import { Package, Video, Users } from "lucide-react";
import { useApiGet } from "@/lib/use-api";
import { useDocumentHead } from "@/lib/use-document-head";

export function AdminDashboardPage() {
  useDocumentHead({ meta: [{ title: "Dashboard — Admin" }] });
  const { data: products } = useApiGet("/api/products");
  const { data: capabilities } = useApiGet("/api/capabilities");
  const { data: stories } = useApiGet("/api/stories");

  const stats = [
    { icon: Package, value: products?.length ?? 0, label: "Products" },
    { icon: Video, value: capabilities?.length ?? 0, label: "Capabilities" },
    { icon: Users, value: stories?.length ?? 0, label: "Customer Stories" },
  ];

  return (
    <div className="admin-page-wrapper">
      <div className="dashboard-grid">
        {stats.map((s) => (
          <div className="stat-card" key={s.label}>
            <div className="stat-icon">
              <s.icon />
            </div>
            <div>
              <div className="stat-value">{s.value}</div>
              <div className="stat-label">{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="admin-card">
        <h3 style={{ fontSize: "1rem", fontWeight: 700, color: "var(--slate-800)", marginBottom: 8 }}>
          Welcome to the ToggleNow CMS
        </h3>
        <p style={{ color: "var(--slate-500)", fontSize: "0.9rem" }}>
          Manage the products, tour capability videos, and customer stories shown across the
          Experience Center from the tabs on the left.
        </p>
      </div>
    </div>
  );
}
